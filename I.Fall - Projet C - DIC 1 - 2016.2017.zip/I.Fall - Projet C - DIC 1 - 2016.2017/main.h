/****************************************
*     Déclaration des bibliotheques     *
****************************************/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
/************************************
*     Définition des constantes     *
************************************/
// Définition de la constante ERREUR
#define QUITTER -2
// Définition de la constante ERREUR
#define ERREUR -1
// Définition de la constante ECHEC
#define ECHEC 0
// Définition de la constante SUCCES
#define SUCCES 1
// Définition de la constante TAILLE_L (Petite taille)
#define TAILLE_L 15
// Définition de la constante TAILLE_XL (taille moyenne)
#define TAILLE_XL 25
// Définition de la constante TAILLE_XXL (taille grande)
#define TAILLE_XXL 50
/***********************************************
* Définition des stuctures et listes chainées  *
************************************************/
// Structure d'un utilisateur
typedef struct utilisateur
{
    char login_utilisateur[TAILLE_XL];
    char mot_de_passe_utilisateur[TAILLE_XL];
    struct utilisateur *suivant;
} utilisateur;
typedef utilisateur* liste_utilisateurs;
// Structure d'un membre
typedef struct membre
{
    char numero_membre[TAILLE_L];
    char nom_membre[TAILLE_XL];
    char prenoms_membre[TAILLE_XL];
    char adresse_membre[TAILLE_XXL];
    struct formation *formations_membre;
    struct membre *suivant;
} membre;
typedef membre* liste_membres;
// Structure d'une formation
typedef struct formation
{
    char code_formation[TAILLE_L];
    char intitule_formation[TAILLE_L];
    char annee_formation[TAILLE_L];
    struct formation *suivant;
} formation;
typedef formation* liste_formations;
