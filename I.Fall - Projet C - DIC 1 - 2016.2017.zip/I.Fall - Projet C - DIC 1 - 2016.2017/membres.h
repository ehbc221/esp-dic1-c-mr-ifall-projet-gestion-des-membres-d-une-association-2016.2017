/***********************************************************************
*     Définition des fonctions relatives aux membres et formations     *
***********************************************************************/
// Créer une liste d'utilisateurs vide
liste_utilisateurs creerUtilisateur();
// Ajouter un utilisateur en fin de liste
liste_utilisateurs insererEnQueueUtilisateur(liste_utilisateurs liste, char* login_utilisateur, char* mot_de_passe_utilisateur);
// Créer une liste de membres vide
liste_membres creerMembre();
// Ajouter un membre en fin de liste
liste_membres insererEnQueueMembre(liste_membres liste, char numero_membre[TAILLE_L], char nom_membre[TAILLE_XL], char prenoms_membre[TAILLE_XL], char adresse_membre[TAILLE_XXL], struct formation *formations_membre);
// Afficher la liste des membres
void afficherListeMembres(liste_membres liste);
// Créer une liste de formations vide
liste_formations creerFormation();
